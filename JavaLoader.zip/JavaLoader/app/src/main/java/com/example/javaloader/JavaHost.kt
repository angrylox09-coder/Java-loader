package com.example.javaloader

import android.content.Context
import android.content.Intent
import org.json.JSONObject
import java.io.File

data class HostApp(val label: String, val packageName: String)

sealed interface HostState {
    data object NotInstalled : HostState
    data class Ready(val app: HostApp, val launch: Intent) : HostState
}

/**
 * Minecraft: Java Edition can't run inside a plain Android app: it needs a Java runtime and an
 * OpenGL layer. This object is the seam where JavaLoader hands off to such a launcher.
 *
 * To support another launcher, add it to [known] and to <queries> in AndroidManifest.xml.
 * (Double-check the package names against the launcher's store page before relying on them.)
 */
object JavaHost {
    val known = listOf(
        HostApp("PojavLauncher", "net.kdt.pojavlaunch"),
        HostApp("Zalith Launcher", "com.movtery.zalithlauncher"),
        HostApp("FCL", "com.tungsten.fcl"),
    )

    fun detect(context: Context): HostState {
        val pm = context.packageManager
        for (app in known) {
            val intent = pm.getLaunchIntentForPackage(app.packageName)
            if (intent != null) return HostState.Ready(app, intent)
        }
        return HostState.NotInstalled
    }

    /**
     * Saves the current choice as selection.json in the app's external files dir so an
     * integration (or you) can read it. Nothing reads it automatically yet.
     */
    fun writeSelection(context: Context, version: String, pack: String?) {
        try {
            val dir = context.getExternalFilesDir(null) ?: context.filesDir
            val json = JSONObject()
                .put("edition", "java")
                .put("version", version)
                .put("shaderPack", pack ?: JSONObject.NULL)
            File(dir, "selection.json").writeText(json.toString(2))
        } catch (e: Exception) {
            // Best-effort only.
        }
    }
}
