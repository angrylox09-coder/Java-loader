package com.example.javaloader

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

object Palette {
    val BG = 0xFF0E1116.toInt()
    val CARD = 0xFF171B22.toInt()
    val STROKE = 0xFF262C36.toInt()
    val TEXT = 0xFFE8ECF1.toInt()
    val MUTED = 0xFF8B94A3.toInt()
    val ACCENT = 0xFF3DDC84.toInt()
    val ACCENT_DIM = 0xFF163A28.toInt()
    val WARN = 0xFFF2B84B.toInt()
    val WARN_DIM = 0xFF3A2E12.toInt()
}

object Fonts {
    val heading: Typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
    val body: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    val medium: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
}

fun Context.dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

fun rounded(color: Int, radiusPx: Float, strokeColor: Int = 0, strokePx: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = radiusPx
        setColor(color)
        if (strokePx > 0) setStroke(strokePx, strokeColor)
    }

fun ripple(content: Drawable, radiusPx: Float, rippleColor: Int = 0x33FFFFFF): RippleDrawable {
    val mask = GradientDrawable().apply {
        cornerRadius = radiusPx
        setColor(Color.WHITE)
    }
    return RippleDrawable(ColorStateList.valueOf(rippleColor), content, mask)
}

/** Adds [child] to this LinearLayout. w/h are raw px or MATCH/WRAP; margins are in dp. */
fun <T : View> LinearLayout.add(
    child: T,
    w: Int = MATCH,
    h: Int = WRAP,
    top: Int = 0,
    bottom: Int = 0,
    left: Int = 0,
    right: Int = 0,
    weight: Float = 0f,
): T {
    val p = LinearLayout.LayoutParams(w, h, weight)
    p.setMargins(context.dp(left), context.dp(top), context.dp(right), context.dp(bottom))
    addView(child, p)
    return child
}

fun Context.label(
    value: CharSequence,
    sizeSp: Float = 14f,
    color: Int = Palette.TEXT,
    face: Typeface = Fonts.body,
    spacing: Float = 0f,
): TextView = TextView(this).apply {
    text = value
    textSize = sizeSp
    setTextColor(color)
    typeface = face
    letterSpacing = spacing
}

fun Context.pill(value: String, fg: Int, bg: Int): TextView = TextView(this).apply {
    text = value
    textSize = 12f
    typeface = Fonts.medium
    setTextColor(fg)
    setPadding(dp(12), dp(6), dp(12), dp(6))
    background = rounded(bg, dp(20).toFloat())
}

fun Context.card(padDp: Int = 16, onClick: (() -> Unit)? = null): LinearLayout {
    val r = dp(16).toFloat()
    val base = rounded(Palette.CARD, r, Palette.STROKE, dp(1))
    return LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(padDp), dp(padDp), dp(padDp), dp(padDp))
        if (onClick != null) {
            background = ripple(base, r)
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
        } else {
            background = base
        }
    }
}

fun Context.primaryButton(title: String, onClick: () -> Unit): TextView {
    val r = dp(16).toFloat()
    return TextView(this).apply {
        text = title
        textSize = 18f
        typeface = Fonts.heading
        letterSpacing = 0.12f
        setTextColor(Palette.BG)
        gravity = Gravity.CENTER
        minHeight = dp(58)
        background = ripple(rounded(Palette.ACCENT, r), r, 0x33000000)
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
    }
}

fun Context.ghostButton(title: String, onClick: () -> Unit): TextView {
    val r = dp(14).toFloat()
    return TextView(this).apply {
        text = title
        textSize = 14f
        typeface = Fonts.medium
        setTextColor(Palette.TEXT)
        gravity = Gravity.CENTER
        minHeight = dp(48)
        background = ripple(rounded(Palette.CARD, r, Palette.STROKE, dp(1)), r)
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
    }
}

fun Context.switchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
): LinearLayout {
    val row = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }
    val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    col.add(label(title, 15f, Palette.TEXT, Fonts.medium))
    col.add(label(subtitle, 12f, Palette.MUTED), top = 2)
    row.add(col, w = 0, weight = 1f)
    val sw = SwitchCompat(this).apply {
        isChecked = checked
        setOnCheckedChangeListener { _, value -> onChange(value) }
    }
    row.add(sw, w = WRAP)
    return row
}

/** A LinearLayout that never gets wider than [maxWidthPx] (keeps tablets tidy). */
class MaxWidthLinearLayout(context: Context, private val maxWidthPx: Int) : LinearLayout(context) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val size = View.MeasureSpec.getSize(widthMeasureSpec)
        val spec = if (size > maxWidthPx) {
            View.MeasureSpec.makeMeasureSpec(maxWidthPx, View.MeasureSpec.getMode(widthMeasureSpec))
        } else {
            widthMeasureSpec
        }
        super.onMeasure(spec, heightMeasureSpec)
    }
}
