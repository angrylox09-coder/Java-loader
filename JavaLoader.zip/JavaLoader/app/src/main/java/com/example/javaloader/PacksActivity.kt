package com.example.javaloader

import android.net.Uri
import android.os.Bundle
import android.text.format.Formatter
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import java.util.concurrent.Executors

class PacksActivity : BaseActivity() {

    private lateinit var prefs: Prefs
    private lateinit var store: PackStore
    private lateinit var listBox: LinearLayout
    private val io = Executors.newSingleThreadExecutor()

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) importAll(uris)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        store = PackStore(this)

        val col = buildScreen()
        backHeader(col, "Shader packs")
        col.add(
            label(
                "Java shader packs (Iris / OptiFine format): a .zip with a shaders/ folder inside. " +
                    "Tap a pack to select it, tap again to go back to vanilla.",
                13f,
                Palette.MUTED,
            ),
            bottom = 16,
        )
        col.add(
            primaryButton("IMPORT .ZIP") {
                picker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
            },
        )
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.add(listBox, top = 16)
        refresh()
    }

    override fun onDestroy() {
        io.shutdownNow()
        super.onDestroy()
    }

    private fun importAll(uris: List<Uri>) {
        io.execute {
            val results = uris.map { store.import(it) }
            val ok = results.count { it is ImportResult.Imported }
            val firstFail = results.filterIsInstance<ImportResult.Failed>().firstOrNull()?.reason.orEmpty()
            runOnUiThread {
                if (!isDestroyed) {
                    refresh()
                    toast(
                        when {
                            firstFail.isEmpty() -> "Imported $ok pack(s)"
                            ok > 0 -> "Imported $ok, skipped some: $firstFail"
                            else -> firstFail
                        },
                    )
                }
            }
        }
    }

    private fun refresh() {
        listBox.removeAllViews()
        val items = store.list()
        if (items.isEmpty()) {
            listBox.add(
                label("No packs yet. Import a .zip to get started.", 14f, Palette.MUTED)
                    .apply { gravity = Gravity.CENTER },
                top = 24,
            )
            return
        }
        for (pack in items) {
            listBox.add(packRow(pack), top = 10)
        }
    }

    private fun packRow(pack: ShaderPack): View {
        val selected = prefs.selectedPack == pack.file.name
        val row = card(14, onClick = {
            prefs.selectedPack = if (selected) null else pack.file.name
            refresh()
        })
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        inner.add(
            label(if (selected) "\u25CF" else "\u25CB", 20f, if (selected) Palette.ACCENT else Palette.MUTED)
                .apply { setPadding(0, 0, dp(12), 0) },
            w = WRAP,
        )
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        info.add(label(pack.displayName, 15f, Palette.TEXT, Fonts.medium))
        val size = Formatter.formatShortFileSize(this, pack.sizeBytes)
        info.add(label(if (selected) "$size \u00B7 Selected" else size, 12f, Palette.MUTED), top = 2)
        inner.add(info, w = 0, weight = 1f)
        inner.add(
            label("Delete", 13f, Palette.WARN, Fonts.medium).apply {
                setPadding(dp(12), dp(8), dp(4), dp(8))
                isClickable = true
                setOnClickListener { confirmDelete(pack) }
            },
            w = WRAP,
        )
        row.add(inner)
        return row
    }

    private fun confirmDelete(pack: ShaderPack) {
        AlertDialog.Builder(this)
            .setTitle("Delete pack?")
            .setMessage(pack.file.name)
            .setPositiveButton("Delete") { _, _ ->
                store.delete(pack)
                if (prefs.selectedPack == pack.file.name) prefs.selectedPack = null
                refresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
