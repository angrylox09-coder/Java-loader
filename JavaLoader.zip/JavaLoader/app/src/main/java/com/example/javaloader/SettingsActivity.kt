package com.example.javaloader

import android.os.Bundle
import android.widget.TextView
import java.util.concurrent.Executors

class SettingsActivity : BaseActivity() {

    private val io = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Prefs(this)
        val repo = VersionRepository(this)

        val col = buildScreen()
        backHeader(col, "Settings")

        // Versions
        col.add(section("VERSIONS"))
        val versions = card()
        versions.add(
            switchRow("Show snapshots", "Weekly development builds", prefs.showSnapshots) {
                prefs.showSnapshots = it
            },
        )
        versions.add(
            switchRow("Show old versions", "Beta and alpha releases", prefs.showOldVersions) {
                prefs.showOldVersions = it
            },
            top = 14,
        )
        versions.add(
            ghostButton("Refresh version list") {
                toast("Refreshing\u2026")
                io.execute {
                    val message = try {
                        "${repo.fetch().versions.size} Java versions in the list"
                    } catch (e: Exception) {
                        "Couldn't reach Mojang \u2014 keeping the saved list"
                    }
                    runOnUiThread { if (!isDestroyed) toast(message) }
                }
            },
            top = 16,
        )
        col.add(versions, top = 8)

        // Launcher
        col.add(section("JAVA LAUNCHER"), top = 24)
        val launcher = card()
        val status: TextView = label("", 15f, Palette.TEXT, Fonts.medium)
        launcher.add(status)
        launcher.add(
            label(
                "JavaLoader hands the game off to one of: " +
                    JavaHost.known.joinToString(", ") { it.label } + ".",
                12f,
                Palette.MUTED,
            ),
            top = 4,
        )
        val host = JavaHost.detect(this)
        if (host is HostState.Ready) {
            status.text = "\u25CF ${host.app.label} found"
            status.setTextColor(Palette.ACCENT)
        } else {
            status.text = "\u25CF No supported launcher installed"
            status.setTextColor(Palette.WARN)
        }
        col.add(launcher, top = 8)

        // About
        col.add(section("ABOUT"), top = 24)
        val about = card()
        about.add(label("JavaLoader 0.1.0", 15f, Palette.TEXT, Fonts.medium))
        about.add(
            label(
                "Minecraft: Java Edition only. Not affiliated with Mojang or Microsoft. " +
                    "Minecraft is a trademark of Mojang AB.",
                12f,
                Palette.MUTED,
            ),
            top = 4,
        )
        col.add(about, top = 8)
    }

    override fun onDestroy() {
        io.shutdownNow()
        super.onDestroy()
    }

    private fun section(title: String): TextView = label(title, 12f, Palette.MUTED, Fonts.medium, 0.15f)
}
