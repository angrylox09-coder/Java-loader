package com.example.javaloader

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("javaloader", Context.MODE_PRIVATE)

    /** Selected Minecraft: Java Edition version id, e.g. "1.21.1". Null = latest release. */
    var selectedVersion: String?
        get() = sp.getString("version", null)
        set(value) = sp.edit().putString("version", value).apply()

    /** File name of the selected shader pack inside the pack folder. Null = none (vanilla). */
    var selectedPack: String?
        get() = sp.getString("pack", null)
        set(value) = sp.edit().putString("pack", value).apply()

    var showSnapshots: Boolean
        get() = sp.getBoolean("snapshots", false)
        set(value) = sp.edit().putBoolean("snapshots", value).apply()

    var showOldVersions: Boolean
        get() = sp.getBoolean("old_versions", false)
        set(value) = sp.edit().putBoolean("old_versions", value).apply()
}
