package com.example.javaloader

import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import java.util.concurrent.Executors

class MainActivity : BaseActivity() {

    private lateinit var prefs: Prefs
    private lateinit var repo: VersionRepository
    private lateinit var packs: PackStore
    private val io = Executors.newSingleThreadExecutor()

    private var manifest: VersionManifest? = null
    private var loadError: String? = null
    private var host: HostState = HostState.NotInstalled

    private lateinit var statusPill: TextView
    private lateinit var versionValue: TextView
    private lateinit var versionTag: TextView
    private lateinit var versionHint: TextView
    private lateinit var packValue: TextView
    private lateinit var playSub: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        repo = VersionRepository(this)
        packs = PackStore(this)
        buildUi()
        loadVersions()
    }

    override fun onResume() {
        super.onResume()
        host = JavaHost.detect(this)
        renderHost()
        renderVersion()
        renderPack()
    }

    override fun onRestart() {
        super.onRestart()
        // Coming back from Settings: pick up a refreshed version list.
        io.execute {
            val cached = repo.loadCached()
            if (cached != null) {
                runOnUiThread {
                    if (!isDestroyed) {
                        manifest = cached
                        renderVersion()
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        io.shutdownNow()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- UI

    private fun buildUi() {
        val col = buildScreen()

        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.add(ImageView(this).apply { setImageResource(R.drawable.ic_mark) }, w = dp(28), h = dp(28))
        header.add(
            label("JAVALOADER", 22f, Palette.TEXT, Fonts.heading, 0.1f).apply { setPadding(dp(10), 0, 0, 0) },
            w = WRAP,
        )
        col.add(header, bottom = 16)

        // Hero banner
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(20))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF1D4A33.toInt(), 0xFF12202A.toInt(), Palette.BG),
            ).apply { cornerRadius = dp(20).toFloat() }
        }
        hero.add(label("MINECRAFT", 13f, Palette.ACCENT, Fonts.heading, 0.2f))
        hero.add(label("JAVA EDITION", 40f, Palette.TEXT, Fonts.heading, 0.03f), top = 2)
        hero.add(label("Pick a Java version, pick a shader pack, play.", 14f, Palette.MUTED), top = 6)
        statusPill = pill("", Palette.MUTED, Palette.CARD)
        hero.add(statusPill, w = WRAP, top = 16)
        col.add(hero)

        // Version card
        val versionCard = card(onClick = { onVersionTap() })
        versionCard.add(label("VERSION", 12f, Palette.MUTED, Fonts.medium, 0.15f))
        val vRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        versionValue = label("\u2014", 32f, Palette.TEXT, Fonts.heading)
        versionTag = label("", 11f, Palette.ACCENT, Fonts.medium, 0.1f).apply { setPadding(dp(10), 0, 0, 0) }
        vRow.add(versionValue, w = WRAP)
        vRow.add(versionTag, w = WRAP)
        vRow.add(View(this), w = 0, h = 1, weight = 1f)
        vRow.add(label("\u25BE", 18f, Palette.MUTED), w = WRAP)
        versionCard.add(vRow, top = 2)
        versionHint = label("", 12f, Palette.MUTED)
        versionCard.add(versionHint, top = 4)
        col.add(versionCard, top = 12)

        // Shader pack card
        val packCard = card(onClick = { startActivity(Intent(this, PacksActivity::class.java)) })
        packCard.add(label("SHADER PACK", 12f, Palette.MUTED, Fonts.medium, 0.15f))
        val pRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        packValue = label("None (vanilla)", 18f, Palette.TEXT, Fonts.medium)
        pRow.add(packValue, w = 0, weight = 1f)
        pRow.add(label("\u203A", 22f, Palette.MUTED), w = WRAP)
        packCard.add(pRow, top = 4)
        col.add(packCard, top = 12)

        // Play
        col.add(primaryButton("PLAY") { onPlay() }, top = 20)
        playSub = label("", 12f, Palette.MUTED).apply { gravity = Gravity.CENTER }
        col.add(playSub, top = 8)

        // Navigation
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        nav.add(
            ghostButton("Shader packs") { startActivity(Intent(this, PacksActivity::class.java)) },
            w = 0, weight = 1f, right = 6,
        )
        nav.add(
            ghostButton("Settings") { startActivity(Intent(this, SettingsActivity::class.java)) },
            w = 0, weight = 1f, left = 6,
        )
        col.add(nav, top = 20)

        col.add(
            label("Java Edition only \u00B7 versions from Mojang's official list", 12f, Palette.MUTED)
                .apply { gravity = Gravity.CENTER },
            top = 24,
        )
    }

    private fun setPill(fg: Int, bg: Int) {
        statusPill.setTextColor(fg)
        statusPill.background = rounded(bg, dp(20).toFloat())
    }

    private fun renderHost() {
        when (val h = host) {
            is HostState.Ready -> {
                statusPill.text = "\u25CF ${h.app.label} found"
                setPill(Palette.ACCENT, Palette.ACCENT_DIM)
                playSub.text = "Opens ${h.app.label}"
            }
            HostState.NotInstalled -> {
                statusPill.text = "\u25CF No Java launcher found"
                setPill(Palette.WARN, Palette.WARN_DIM)
                playSub.text = "Install a Java launcher to play"
            }
        }
    }

    private fun selectedId(): String? = prefs.selectedVersion ?: manifest?.latestRelease

    private fun typeLabel(type: String): String = when (type) {
        "release" -> "RELEASE"
        "snapshot" -> "SNAPSHOT"
        "old_beta" -> "OLD BETA"
        "old_alpha" -> "OLD ALPHA"
        else -> type.uppercase()
    }

    private fun renderVersion() {
        val m = manifest
        val id = selectedId()
        versionValue.text = id ?: "\u2014"
        versionTag.text = when {
            id == null -> ""
            m != null && id == m.latestRelease -> "LATEST RELEASE"
            else -> m?.versions?.firstOrNull { it.id == id }?.let { typeLabel(it.type) } ?: ""
        }
        versionHint.text = when {
            m == null && loadError != null -> loadError
            m == null -> "Loading versions\u2026"
            m.fromCache -> "Offline list \u00B7 ${m.visible(prefs).size} versions"
            else -> "${m.visible(prefs).size} Java versions available"
        }
    }

    private fun renderPack() {
        val name = prefs.selectedPack
        val exists = name != null && packs.list().any { it.file.name == name }
        if (name != null && !exists) prefs.selectedPack = null
        packValue.text = if (exists && name != null) name.removeSuffix(".zip") else "None (vanilla)"
    }

    // ---------------------------------------------------------------- data

    private fun loadVersions() {
        loadError = null
        renderVersion()
        io.execute {
            val cached = repo.loadCached()
            if (cached != null) {
                runOnUiThread {
                    if (!isDestroyed) {
                        manifest = cached
                        renderVersion()
                    }
                }
            }
            try {
                val fresh = repo.fetch()
                runOnUiThread {
                    if (!isDestroyed) {
                        manifest = fresh
                        loadError = null
                        renderVersion()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (!isDestroyed && manifest == null) {
                        loadError = "Couldn't load the version list. Tap to retry."
                        renderVersion()
                    }
                }
            }
        }
    }

    // ---------------------------------------------------------------- actions

    private fun onVersionTap() {
        if (manifest == null) {
            loadVersions()
        } else {
            showVersionPicker()
        }
    }

    private fun describe(m: VersionManifest, v: McVersion): String = when {
        v.id == m.latestRelease -> "${v.id}  \u00B7  latest"
        v.type == "snapshot" -> "${v.id}  \u00B7  snapshot"
        v.type == "old_beta" -> "${v.id}  \u00B7  beta"
        v.type == "old_alpha" -> "${v.id}  \u00B7  alpha"
        else -> v.id
    }

    private fun showVersionPicker() {
        val m = manifest ?: return
        val all = m.visible(prefs)
        var shown = all

        val versionAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            ArrayList(all.map { describe(m, it) }),
        )
        val search = EditText(this).apply {
            hint = "Search (e.g. 1.20)"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        }
        val list = ListView(this)
        list.adapter = versionAdapter

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        box.add(search)
        box.add(list, h = dp(360), top = 8)

        val dialog = AlertDialog.Builder(this)
            .setTitle("Java version")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .create()

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString().orEmpty().trim()
                shown = if (q.isEmpty()) all else all.filter { it.id.contains(q, ignoreCase = true) }
                versionAdapter.clear()
                versionAdapter.addAll(shown.map { describe(m, it) })
                versionAdapter.notifyDataSetChanged()
            }
        })
        list.setOnItemClickListener { _, _, position, _ ->
            val picked = shown.getOrNull(position)
            if (picked != null) {
                prefs.selectedVersion = picked.id
                renderVersion()
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun onPlay() {
        val id = selectedId()
        if (id == null) {
            toast("Pick a version first")
            return
        }
        when (val h = host) {
            is HostState.Ready -> {
                JavaHost.writeSelection(this, id, prefs.selectedPack)
                try {
                    startActivity(h.launch)
                } catch (e: Exception) {
                    toast("Couldn't open ${h.app.label}")
                }
            }
            HostState.NotInstalled -> {
                val names = JavaHost.known.joinToString(", ") { it.label }
                AlertDialog.Builder(this)
                    .setTitle("No Java launcher found")
                    .setMessage(
                        "Minecraft: Java Edition needs a Java runtime that a regular app can't provide, " +
                            "so JavaLoader hands off to an installed launcher.\n\nSupported: $names.\n\n" +
                            "Install one, then press Play again.",
                    )
                    .setPositiveButton("OK", null)
                    .show()
            }
        }
    }
}
