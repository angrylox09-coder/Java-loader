package com.example.javaloader

import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

abstract class BaseActivity : AppCompatActivity() {

    /** Sets up a scrolling, width-capped column and returns it. */
    protected fun buildScreen(): LinearLayout {
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = false
            setBackgroundColor(Palette.BG)
        }
        val frame = FrameLayout(this)
        val column = MaxWidthLinearLayout(this, dp(560)).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(32))
        }
        frame.addView(column, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.CENTER_HORIZONTAL))
        scroll.addView(frame, ViewGroup.LayoutParams(MATCH, WRAP))
        setContentView(scroll)
        return column
    }

    protected fun backHeader(parent: LinearLayout, title: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val back = label("\u2190", 26f, Palette.TEXT).apply {
            setPadding(dp(4), dp(8), dp(16), dp(8))
            isClickable = true
            setOnClickListener { finish() }
        }
        row.add(back, w = WRAP)
        row.add(label(title.uppercase(), 26f, Palette.TEXT, Fonts.heading, 0.06f), w = WRAP)
        parent.add(row, bottom = 16)
    }

    protected fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
