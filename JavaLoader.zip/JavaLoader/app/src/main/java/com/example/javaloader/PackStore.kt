package com.example.javaloader

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.FileFilter
import java.util.zip.ZipFile

data class ShaderPack(val file: File) {
    val displayName: String get() = file.nameWithoutExtension
    val sizeBytes: Long get() = file.length()
}

sealed interface ImportResult {
    data class Imported(val pack: ShaderPack) : ImportResult
    data class Failed(val reason: String) : ImportResult
}

/** Keeps imported Java shader packs (Iris / OptiFine format: a .zip containing shaders/). */
class PackStore(private val context: Context) {

    val dir: File = (context.getExternalFilesDir("shaderpacks") ?: File(context.filesDir, "shaderpacks"))
        .also { it.mkdirs() }

    fun list(): List<ShaderPack> =
        dir.listFiles(FileFilter { it.isFile && it.extension.equals("zip", ignoreCase = true) })
            ?.sortedBy { it.name.lowercase() }
            ?.map { ShaderPack(it) }
            ?: emptyList()

    fun delete(pack: ShaderPack) {
        pack.file.delete()
    }

    /** Copies the picked file into the pack folder after checking it looks like a shader pack. */
    fun import(uri: Uri): ImportResult {
        val name = displayName(uri) ?: "pack.zip"
        if (!name.endsWith(".zip", ignoreCase = true)) {
            return ImportResult.Failed("$name is not a .zip file")
        }
        val target = uniqueTarget(sanitize(name))
        val tmp = File(dir, target.name + ".part")
        try {
            val input = context.contentResolver.openInputStream(uri)
                ?: return ImportResult.Failed("Couldn't open $name")
            input.use { src -> tmp.outputStream().use { dst -> src.copyTo(dst) } }

            if (!looksLikeShaderPack(tmp)) {
                tmp.delete()
                return ImportResult.Failed("$name has no shaders/ folder")
            }
            if (!tmp.renameTo(target)) {
                tmp.delete()
                return ImportResult.Failed("Couldn't save $name")
            }
            return ImportResult.Imported(ShaderPack(target))
        } catch (e: Exception) {
            tmp.delete()
            return ImportResult.Failed("Couldn't import $name (is it a valid zip?)")
        }
    }

    private fun displayName(uri: Uri): String? =
        context.contentResolver
            .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }

    private fun sanitize(name: String): String = name.replace(Regex("[\\\\/:*?\"<>|]"), "_")

    private fun uniqueTarget(name: String): File {
        var f = File(dir, name)
        val stem = name.substringBeforeLast('.')
        val ext = name.substringAfterLast('.', "zip")
        var i = 1
        while (f.exists()) {
            f = File(dir, "$stem ($i).$ext")
            i++
        }
        return f
    }

    private fun looksLikeShaderPack(file: File): Boolean =
        ZipFile(file).use { zip ->
            zip.entries().asSequence().any { SHADERS_ENTRY.matches(it.name) }
        }

    private companion object {
        // "shaders/..." at the top level, or inside a single wrapper folder.
        val SHADERS_ENTRY = Regex("^([^/]+/)?shaders/.+")
    }
}
