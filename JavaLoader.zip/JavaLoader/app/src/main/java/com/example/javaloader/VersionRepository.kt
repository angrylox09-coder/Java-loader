package com.example.javaloader

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class McVersion(val id: String, val type: String, val releaseTime: String)

data class VersionManifest(
    val latestRelease: String,
    val latestSnapshot: String,
    val versions: List<McVersion>,
    val fromCache: Boolean,
) {
    /** Versions allowed by the user's filters. Releases are always shown. */
    fun visible(prefs: Prefs): List<McVersion> = versions.filter {
        when (it.type) {
            "release" -> true
            "snapshot" -> prefs.showSnapshots
            else -> prefs.showOldVersions // old_beta, old_alpha
        }
    }
}

/**
 * Mojang's official launcher manifest. It lists Minecraft: Java Edition versions only,
 * which is exactly what this app is meant to offer.
 */
class VersionRepository(context: Context) {
    private val cache = File(context.filesDir, "version_manifest_v2.json")

    /** Reads the last saved copy, if any. Safe to call off the UI thread. */
    fun loadCached(): VersionManifest? = try {
        if (cache.exists()) parse(cache.readText(), fromCache = true) else null
    } catch (e: Exception) {
        null
    }

    /** Downloads the manifest (and saves it). Throws on network or parse errors. */
    fun fetch(): VersionManifest {
        val json = download()
        val parsed = parse(json, fromCache = false)
        try {
            cache.writeText(json)
        } catch (e: IOException) {
            // Cache is best-effort.
        }
        return parsed
    }

    private fun download(): String {
        val conn = URL(MANIFEST_URL).openConnection() as HttpURLConnection
        conn.connectTimeout = 8_000
        conn.readTimeout = 10_000
        conn.setRequestProperty("User-Agent", "JavaLoader/0.1")
        try {
            if (conn.responseCode != HttpURLConnection.HTTP_OK) {
                throw IOException("HTTP ${conn.responseCode}")
            }
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun parse(json: String, fromCache: Boolean): VersionManifest {
        val root = JSONObject(json)
        val latest = root.getJSONObject("latest")
        val arr = root.getJSONArray("versions")
        val list = ArrayList<McVersion>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(McVersion(o.getString("id"), o.getString("type"), o.optString("releaseTime")))
        }
        return VersionManifest(latest.getString("release"), latest.getString("snapshot"), list, fromCache)
    }

    private companion object {
        const val MANIFEST_URL = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
    }
}
