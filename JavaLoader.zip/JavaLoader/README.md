# JavaLoader

An Android app styled after MagicLoader, but for **Minecraft: Java Edition**.

- **Home**: hero banner, launcher status, Java version picker (live list from Mojang's official
  manifest, searchable, cached for offline), shader pack card, PLAY.
- **Shader packs**: import Java shader packs (.zip containing `shaders/`), select / delete.
- **Settings**: show snapshots / old beta+alpha versions, refresh the list, launcher status.

## Build an APK

**Android Studio** (easiest): File > Open this folder, let Gradle sync, then
Build > Build APK(s). Output: `app/build/outputs/apk/debug/app-debug.apk`.

**GitHub Actions** (no PC needed): push this folder to a GitHub repo. The workflow in
`.github/workflows/build-apk.yml` builds the APK; download it from the run's *Artifacts*.

## What PLAY does (and doesn't)

Java Edition can't run inside a normal Android app: it needs a Java runtime and an OpenGL layer
(what PojavLauncher-style launchers ship). PLAY therefore saves your choice to
`selection.json` (app's external files dir) and opens an installed launcher listed in
`JavaHost.known`. Actually launching the chosen version/shader pack inside that runtime is the
next step: see `JavaHost.kt`.
